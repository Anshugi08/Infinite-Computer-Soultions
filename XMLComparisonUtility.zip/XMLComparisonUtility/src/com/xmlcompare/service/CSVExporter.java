package com.xmlcompare.service; import java.io.*; import java.util.*; import com.xmlcompare.model.Difference; public class CSVExporter { public static void export(List<Difference> d,String p) throws Exception { FileWriter w=new FileWriter(p); w.write("Node,Source,Target,Status
"); for(Difference x:d){ w.write(x.getNode()+","+x.getSource()+","+x.getTarget()+","+x.getStatus()+"
"); } w.close(); }}