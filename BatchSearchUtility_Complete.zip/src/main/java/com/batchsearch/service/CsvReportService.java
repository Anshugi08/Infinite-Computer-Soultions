package com.batchsearch.service; import java.io.*; import java.util.*; import com.batchsearch.model.SearchResult; public class CsvReportService{ public void write(List<SearchResult> data,String file)throws Exception{ FileWriter fw=new FileWriter(file); fw.write("SA_ID,RESULT
"); for(SearchResult r:data){ fw.write(r.getSaId()+","+r.getResult()+"
"); } fw.close(); }}